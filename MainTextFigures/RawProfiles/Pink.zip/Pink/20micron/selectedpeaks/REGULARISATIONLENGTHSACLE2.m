%% ===================== USER PARAMETERS =====================
imgFile      = "PrettyPeakwithRegularisation.png";
threshold    = 0.5;    % binarisation threshold (0-1)

profileSource = "bottom";    % which edge of the white region to fit:
                          %   "top"    = upper edge
                          %   "bottom" = lower edge
                          %   "mean"   = average of top and bottom edges (columns where both exist)
peakDirection = "up";     % "up"   = peak is the smallest row index (points up in the image)
                          % "down" = peak is the largest row index (points down)

% Requested polynomial orders (automatically reduced if a segment has too few points)
orderLeft    = 4;
orderMid     = 4;
orderRight   = 4;

contOrder    = 1;      % continuity at the joins (3-segment fit):
                       %   0 = values match only (derivative will jump)
                       %   1 = values AND slopes match
                       %   2 = values, slopes AND curvature match

% ---- window sweep ----
windowSweep  = 5:1:150;     % candidate middle-window widths in pixels (2 is the minimum possible)
fitMeasure   = "rms";      % "rms" = RMS residual, "max" = worst-case residual
pickTol      = 0.00;       % 0 = absolute minimum. e.g. 0.02 = smallest window whose measure
                           % is within 2% of the minimum (avoids chasing noise)

% ---- window = 0 comparison (two halves meeting at the peak, no middle segment) ----
compareHalves   = true;    % overlay the W = 0 case on every plot
contOrderHalves = 0;       % continuity at the peak: 0 = values only (corner allowed), 1 = + slopes

smoothPeak   = 5;      % moving-mean window used only for locating the peak (1 = none)
flipSlope    = true;   % true -> slope in visual convention (up = positive)
showImage    = true;   % true = draw the image behind the profile plot; false = plain axes

% ---- figure handling ----
isPNG        = true;   % true -> also save each figure as a PNG (only used when saveFigs = true)
showFigs     = true;   % false = figures are created hidden
saveFigs     = true;  % save figures as PNG (works even when hidden)
outPrefix    = strcat(profileSource,"_fit");  % saved: fit_profile.png, fit_derivs.png, fit_rms.png
%% ===========================================================

visStr = "off"; if showFigs, visStr = "on"; end
colBest = [0 0.447 0.741];     % blue  : best-window (3-segment) fit
colHalf = [0.85 0.325 0.098];  % orange: two-halves (W = 0) fit

%% ---------- Load image and extract top edge ----------
im = imread(imgFile);
if size(im,3) == 3, im = rgb2gray(im); end
BW = imbinarize(im, threshold);

% Top edge: first white pixel from the top. Bottom edge: last white pixel.
[hasWhite, topRow] = max(BW, [], 1);
topRow = double(topRow);
topRow(~hasWhite) = NaN;

[~, bFlip] = max(flipud(BW), [], 1);
bottomRow  = size(BW,1) - double(bFlip) + 1;
bottomRow(~hasWhite) = NaN;

profileSource = lower(string(profileSource));
switch profileSource
    case "top"
        edgeRow = topRow;
    case "bottom"
        edgeRow = bottomRow;
    case "mean"
        edgeRow = (topRow + bottomRow) / 2;
    otherwise
        error('profileSource must be "top", "bottom" or "mean".');
end
if profileSource ~= "top" && all(bottomRow(hasWhite) == bottomRow(find(hasWhite,1)))
    warning('Bottom edge is constant (white region likely runs to the image bottom), so "%s" will not follow the profile.', profileSource);
end
fprintf('Profile source: %s edge\n', profileSource);

x     = (1:size(BW,2))';
y     = edgeRow(:);
valid = isfinite(y);

% Locate peak (smallest row index = highest point in the image)
if smoothPeak > 1, yForPeak = smoothdata(y,'movmean',smoothPeak); else, yForPeak = y; end
if lower(string(peakDirection)) == "down"
    [~, peakX] = max(yForPeak);
else
    [~, peakX] = min(yForPeak);
end

%% ---------- Sweep window width ----------
meas    = nan(size(windowSweep));   % residual over the whole profile
measMid = nan(size(windowSweep));   % residual over the middle section only
for i = 1:numel(windowSweep)
    Fi = fitWindow(x, y, valid, peakX, windowSweep(i), ...
                   orderLeft, orderMid, orderRight, contOrder, fitMeasure);
    if Fi.ok
        meas(i) = Fi.meas;  measMid(i) = Fi.measMid;
    end
end

fprintf('Valid windows: %d of %d\n', nnz(~isnan(meas)), numel(meas));
if all(isnan(meas))
    error('No window in windowSweep produced a valid fit. Check the sweep range and image.');
end

[minMeas, iMin] = min(meas);
if pickTol > 0
    iBest = find(meas <= minMeas*(1 + pickTol), 1, 'first');
else
    iBest = iMin;
end
bestW = windowSweep(iBest);

fprintf('Smallest valid window = %d px\n', windowSweep(find(~isnan(meas),1)));
fprintf('Minimum %s (full profile) = %.4f px at window = %d px\n', fitMeasure, minMeas, windowSweep(iMin));
fprintf('Selected window = %d px (%s = %.4f px)\n', bestW, fitMeasure, meas(iBest));

%% ---------- Refit at best window ----------
F = fitWindow(x, y, valid, peakX, bestW, ...
              orderLeft, orderMid, orderRight, contOrder, fitMeasure);
fprintf('Orders used at selected window (L/M/R): %d/%d/%d\n', F.nEff);

xa = F.xa; xb = F.xb;
leftIdx = F.leftIdx; midIdx = F.midIdx; rightIdx = F.rightIdx;

[yFit, dFit, ddFit] = evalFit(F, x);
if flipSlope, dFit = -dFit; ddFit = -ddFit; end

%% ---------- Two-halves case (window = 0) ----------
F0 = struct('ok', false, 'meas', NaN, 'reason', 'unknown');
if compareHalves
    F0 = fitHalves(x, y, valid, peakX, orderLeft, orderRight, contOrderHalves, fitMeasure);
    if F0.ok
        fprintf('Window = 0 (two halves, C^%d at peak): %s = %.4f px, orders L/R = %d/%d\n', ...
            contOrderHalves, fitMeasure, F0.meas, F0.nEff(1), F0.nEff(3));
    else
        warning('Two-halves fit failed: %s. Skipping W = 0 case.', F0.reason);
        compareHalves = false;
    end
end
fprintf('\n');

if compareHalves
    [yHalf, dHalf, ddHalf] = evalFit(F0, x);
    if flipSlope, dHalf = -dHalf; ddHalf = -ddHalf; end

    % Halves residual measured over the whole profile and over the selected window only
    % (no refit: the halves fit is simply compared with the real data in columns xa..xb)
    inWin = x >= xa & x <= xb & valid;
    rH    = y(inWin) - yHalf(inWin);
    if fitMeasure == "max", midHalf = max(abs(rH)); else, midHalf = sqrt(mean(rH.^2)); end
    fullHalf = F0.meas;
end

%% ================= FIGURE 1: fit vs profile =================
figProf = figure('Visible', visStr);
if showImage, imshow(im); else, set(gca, 'YDir', 'reverse'); end
hold on;
hData = plot(x, y, 'r', 'LineWidth', 1);
hBest = plot(x, yFit, '-', 'LineWidth', 2, 'Color', colBest);
hh    = [hData hBest];
names = {sprintf('data edge (%s)', profileSource), sprintf('3-segment (W = %d)', bestW)};
if compareHalves
    hHalf = plot(x, yHalf, '--', 'LineWidth', 2, 'Color', colHalf);
    hh    = [hh hHalf];
    names{end+1} = 'two halves (W = 0)';
end
xline(xa, 'g--'); xline(xb, 'g--');
hold off;
legend(hh, names, 'Location', 'northeast');
title(sprintf('Peak x = %d | orders L/M/R = %d/%d/%d (requested %d/%d/%d) | mid = %d px | C^%d', ...
    peakX, F.nEff, orderLeft, orderMid, orderRight, bestW, contOrder));

%% ================= FIGURE 2: derivatives of the selected fit =================
figDer = figure('Visible', visStr);
subplot(2,1,1);
plot(x, dFit, '-', 'LineWidth', 1.5, 'Color', colBest); hold on;
if compareHalves, plot(x, dHalf, '--', 'LineWidth', 1.5, 'Color', colHalf); end
xline(xa,'g--'); xline(xb,'g--'); yline(0,'k:'); grid on;
ylabel('dy/dx'); title('First derivative');
if compareHalves
    legend(sprintf('3-segment (W = %d)', bestW), 'two halves (W = 0)', 'Location', 'best');
end
subplot(2,1,2);
plot(x, ddFit, '-', 'LineWidth', 1.5, 'Color', colBest); hold on;
if compareHalves, plot(x, ddHalf, '--', 'LineWidth', 1.5, 'Color', colHalf); end
xline(xa,'g--'); xline(xb,'g--'); yline(0,'k:'); grid on;
xlabel('x (pixel column)'); ylabel('d^2y/dx^2'); title('Second derivative');

%% ================= FIGURE 3: RMS residual vs window size =================
figRMS = figure('Visible', visStr);
xl = [min(windowSweep) - 2, max(windowSweep)];
if compareHalves, xl(1) = -2; end

ax1 = subplot(2,1,1);
plotSweepPanel(windowSweep, meas, bestW, meas(iBest), compareHalves, fullHalf, ...
    colBest, colHalf, sprintf('%s residual (px)', upper(fitMeasure)), ...
    'Over the full profile');
xlim(xl);

ax2 = subplot(2,1,2);
if compareHalves
    halfLbl = sprintf('two halves (W = 0), evaluated over x = %d..%d', xa, xb);
    plotSweepPanel(windowSweep, measMid, bestW, measMid(iBest), true, midHalf, ...
        colBest, colHalf, sprintf('%s residual (px)', upper(fitMeasure)), ...
        'Inside the middle section only', halfLbl);
else
    plotSweepPanel(windowSweep, measMid, bestW, measMid(iBest), false, NaN, ...
        colBest, colHalf, sprintf('%s residual (px)', upper(fitMeasure)), ...
        'Inside the middle section only');
end
xlim(xl);
xlabel('Middle window width (px)');
linkaxes([ax1 ax2], 'x');

%% ---------- Save ----------
if saveFigs
    % CreateFcn makes a figure saved while hidden appear when the .fig is opened later
    for f = [figProf figDer figRMS]
        set(f, 'CreateFcn', 'set(gcbf,''Visible'',''on'')');
    end
    savefig(figProf, char(outPrefix + "_profile.fig"));
    savefig(figDer,  char(outPrefix + "_derivs.fig"));
    savefig(figRMS,  char(outPrefix + "_rms.fig"));
    fprintf('Saved %s_profile.fig, %s_derivs.fig, %s_rms.fig\n', outPrefix, outPrefix, outPrefix);

    if isPNG
        exportgraphics(figProf, outPrefix + "_profile.png", 'Resolution', 200);
        exportgraphics(figDer,  outPrefix + "_derivs.png",  'Resolution', 200);
        exportgraphics(figRMS,  outPrefix + "_rms.png",     'Resolution', 200);
        fprintf('Saved %s_profile.png, %s_derivs.png, %s_rms.png\n', outPrefix, outPrefix, outPrefix);
    end
    fprintf('\n');
end
%% ---------- Diagnostics: best window ----------
res = y - yFit;
rmsOf = @(v) sqrt(mean(v.^2, 'omitnan'));
fprintf('--- Best window (W = %d) ---\n', bestW);
fprintf('Mean residual  L: %.2f  M: %.2f  R: %.2f px\n', ...
    mean(res(leftIdx),'omitnan'), mean(res(midIdx),'omitnan'), mean(res(rightIdx),'omitnan'));
fprintf('RMS residual   L: %.2f  M: %.2f  R: %.2f px\n', ...
    rmsOf(res(leftIdx)), rmsOf(res(midIdx)), rmsOf(res(rightIdx)));
for k = 0:2
    ja = pd(F.cM,-1,F.h(2),k) - pd(F.cL,0,F.h(1),k);   % at xa: mid u=-1, left u=0
    jb = pd(F.cR, 0,F.h(3),k) - pd(F.cM,+1,F.h(2),k);  % at xb: mid u=+1, right u=0
    fprintf('Jump in d^%d at xa: %9.2e   at xb: %9.2e\n', k, ja, jb);
end

%% ---------- Diagnostics: comparison with W = 0 ----------
if compareHalves
    fprintf('\n--- Two halves (W = 0), peak at x = %d ---\n', peakX);
    for k = 0:2
        jp = pd(F0.cR,0,F0.h(3),k) - pd(F0.cL,0,F0.h(1),k);
        fprintf('Jump in d^%d at peak: %9.2e\n', k, jp);
    end

    sgn = 1 - 2*flipSlope;     % +1 or -1 so the printed slope jump matches the plotted convention
    slopeJumpHalf = sgn * (pd(F0.cR,0,F0.h(3),1) - pd(F0.cL,0,F0.h(1),1));

    fprintf('\n===== COMPARISON =====\n');
    fprintf('%-30s %14s %14s\n', '', sprintf('W=%d (3-seg)', bestW), 'W=0 (halves)');
    fprintf('%-30s %14.4f %14.4f\n', sprintf('%s full profile (px)',   upper(fitMeasure)), F.meas,    fullHalf);
    fprintf('%-30s %14.4f %14.4f\n', sprintf('%s in window only (px)', upper(fitMeasure)), F.measMid, midHalf);
    fprintf('%-30s %14.4f %14.4f\n', 'Max |dy/dx|',   max(abs(dFit),[],'omitnan'),  max(abs(dHalf),[],'omitnan'));
    fprintf('%-30s %14.4f %14.4f\n', 'Max |d2y/dx2|', max(abs(ddFit),[],'omitnan'), max(abs(ddHalf),[],'omitnan'));
    fprintf('%-30s %14s %14.4f\n',   'Slope jump at peak (dy/dx)', 'n/a (C^1)', slopeJumpHalf);
    if contOrder == 0
        fprintf('(3-segment fit uses contOrder = 0, so its slope jumps at xa and xb instead; see above.)\n');
    end
end

%% ---------------- local functions (must be at end of script) ----------------
function plotSweepPanel(W, vals, bestW, bestVal, haveHalf, halfVal, cB, cH, yl, ttl, halfLbl)
    % One panel of residual-vs-window: sweep curve, selected window, optional W = 0 reference
    if nargin < 11, halfLbl = 'two halves (W = 0)'; end
    h1 = plot(W, vals, 'o-', 'LineWidth', 1.5, 'Color', cB); hold on;
    h2 = plot(bestW, bestVal, 'rp', 'MarkerSize', 14, 'MarkerFaceColor', 'r');
    hs = [h1 h2];
    nm = {'3-segment fit', sprintf('selected window (%d px)', bestW)};
    if haveHalf
        h3 = plot(0, halfVal, 's', 'MarkerSize', 9, 'MarkerFaceColor', cH, 'MarkerEdgeColor', 'k');
        yline(halfVal, '--', 'Color', cH, 'LineWidth', 1.2);
        hs = [hs h3];
        nm{end+1} = halfLbl;
    end
    hold off; grid on;
    ylabel(yl); title(ttl);
    legend(hs, nm, 'Location', 'best');
end

function F = fitWindow(x, y, valid, peakX, W, nL, nM, nR, cont, measure)
    % Joint constrained piecewise fit for one middle-window width W.
    % Per-segment local scaling; polynomial orders reduced automatically
    % when a segment has too few points.
    F = struct('ok', false, 'meas', NaN, 'measMid', NaN);
    if W < 2, return; end

    halfL = floor(W/2);  halfR = W - halfL;
    xa = peakX - halfL;  xb = peakX + halfR - 1;

    leftIdx  = x <  xa;
    midIdx   = x >= xa & x <= xb;
    rightIdx = x >  xb;
    iL = leftIdx & valid;  iM = midIdx & valid;  iR = rightIdx & valid;

    % Automatic order reduction: degree <= npoints - 1
    nL = min(nL, nnz(iL) - 1);
    nM = min(nM, nnz(iM) - 1);
    nR = min(nR, nnz(iR) - 1);
    if nL < 0 || nM < 0 || nR < 0, return; end

    % Local centres and scales: u = (x - xc)/h
    xcM = (xa + xb)/2;   hM = (xb - xa)/2;             % mid spans u = -1 .. +1
    xcL = xa;            hL = max(abs(x(iL) - xcL));   % left join at u = 0
    xcR = xb;            hR = max(abs(x(iR) - xcR));   % right join at u = 0
    if hL == 0 || hR == 0 || hM == 0, return; end

    A = blkdiag(((x(iL)-xcL)/hL).^(0:nL), ...
                ((x(iM)-xcM)/hM).^(0:nM), ...
                ((x(iR)-xcR)/hR).^(0:nR));
    b = [y(iL); y(iM); y(iR)];

    % Continuity rows (scaled by hM^k so entries stay O(1))
    C = zeros(0, nL+nM+nR+3);
    for k = 0:cont
        sc = hM^k;
        ra = sc * [ prow(nL, 0, hL, k), -prow(nM, -1, hM, k), zeros(1,nR+1) ];
        rb = sc * [ zeros(1,nL+1),       prow(nM, +1, hM, k), -prow(nR, 0, hR, k) ];
        C  = [C; ra; rb]; %#ok<AGROW>
    end
    nc = size(C,1);

    % Null-space method via explicit SVD (constraints satisfied exactly)
    [~, ~, V] = svd(C);
    sv = svd(C);
    if numel(sv) < nc || sv(end) < 1e-10*sv(1), return; end   % dependent constraints
    N  = V(:, nc+1:end);
    AN = A*N;
    if isempty(N) || rank(AN) < size(N,2), return; end        % not enough data to pin the fit
    w = N * (AN \ b);

    F.cL = w(1:nL+1);
    F.cM = w(nL+2 : nL+nM+2);
    F.cR = w(nL+nM+3 : nL+nM+nR+3);

    yF = nan(size(x));
    yF(leftIdx)  = pd(F.cL, (x(leftIdx)  - xcL)/hL, hL, 0);
    yF(midIdx)   = pd(F.cM, (x(midIdx)   - xcM)/hM, hM, 0);
    yF(rightIdx) = pd(F.cR, (x(rightIdx) - xcR)/hR, hR, 0);

    r = y(valid) - yF(valid);                              % full profile
    if measure == "max", F.meas = max(abs(r)); else, F.meas = sqrt(mean(r.^2)); end
    rM = y(iM) - yF(iM);                                   % middle section only
    if measure == "max", F.measMid = max(abs(rM)); else, F.measMid = sqrt(mean(rM.^2)); end

    F.ok = true;
    F.xa = xa; F.xb = xb;
    F.cen  = [xcL xcM xcR];
    F.h    = [hL hM hR];
    F.nEff = [nL nM nR];                       % orders actually used
    F.leftIdx = leftIdx; F.midIdx = midIdx; F.rightIdx = rightIdx;
end

function F = fitHalves(x, y, valid, peakX, nL, nR, cont, measure)
    % Window = 0 case: two polynomial halves that meet at the peak (x = peakX).
    % Left uses x <= peakX, right uses x > peakX; the constraint at peakX forces
    % derivatives 0..cont to match. Stored in the same layout as fitWindow
    % (empty middle segment) so evalFit works on both.
    F = struct('ok', false, 'meas', NaN, 'reason', 'unknown');

    xp = peakX;
    leftIdx  = x <= xp;
    rightIdx = x >  xp;
    iL = leftIdx & valid;  iR = rightIdx & valid;

    nL = min(nL, nnz(iL) - 1);
    nR = min(nR, nnz(iR) - 1);
    if nL < 0 || nR < 0
        F.reason = sprintf('no valid points on one side of the peak (left %d, right %d, peak at x = %d of %d)', ...
            nnz(iL), nnz(iR), xp, numel(x));
        return;
    end

    hL = max(abs(x(iL) - xp));  hR = max(abs(x(iR) - xp));
    if hL == 0 || hR == 0
        F.reason = sprintf('one half has zero width (peak at x = %d of %d)', xp, numel(x));
        return;
    end

    A = blkdiag(((x(iL)-xp)/hL).^(0:nL), ((x(iR)-xp)/hR).^(0:nR));
    b = [y(iL); y(iR)];

    sc = min(hL, hR);
    C = zeros(0, nL+nR+2);
    for k = 0:cont
        C = [C; sc^k * [prow(nL, 0, hL, k), -prow(nR, 0, hR, k)]]; %#ok<AGROW>
    end
    nc = size(C,1);

    [~, ~, V] = svd(C);
    sv = svd(C);          % singular values as a vector (diag(Sc) breaks when C has a single row)
    if numel(sv) < nc || sv(end) < 1e-10*sv(1)
        F.reason = sprintf('continuity constraints are dependent (%d constraints, orders %d/%d; try lowering contOrderHalves)', ...
            nc, nL, nR);
        return;
    end
    N  = V(:, nc+1:end);
    AN = A*N;
    if isempty(N) || rank(AN) < size(N,2)
        F.reason = sprintf('rank-deficient: rank %d < %d free parameters (%d left pts, %d right pts, orders %d/%d)', ...
            rank(AN), size(N,2), nnz(iL), nnz(iR), nL, nR);
        return;
    end
    w = N * (AN \ b);

    F.cL = w(1:nL+1);
    F.cM = [];
    F.cR = w(nL+2 : nL+nR+2);

    yF = nan(size(x));
    yF(leftIdx)  = pd(F.cL, (x(leftIdx)  - xp)/hL, hL, 0);
    yF(rightIdx) = pd(F.cR, (x(rightIdx) - xp)/hR, hR, 0);
    r = y(valid) - yF(valid);
    if measure == "max", F.meas = max(abs(r)); else, F.meas = sqrt(mean(r.^2)); end

    F.ok = true;
    F.xa = xp; F.xb = xp;
    F.cen  = [xp NaN xp];
    F.h    = [hL NaN hR];
    F.nEff = [nL NaN nR];
    F.leftIdx = leftIdx; F.midIdx = false(size(x)); F.rightIdx = rightIdx;
end

function [y0, d1, d2] = evalFit(F, x)
    % Evaluate fitted profile, first and second derivative on all columns x
    y0 = nan(size(x));  d1 = nan(size(x));  d2 = nan(size(x));
    segs = {F.leftIdx,  F.cL, F.cen(1), F.h(1); ...
            F.midIdx,   F.cM, F.cen(2), F.h(2); ...
            F.rightIdx, F.cR, F.cen(3), F.h(3)};
    for s = 1:3
        idx = segs{s,1};
        if ~any(idx), continue; end
        c = segs{s,2};  xc = segs{s,3};  h = segs{s,4};
        u = (x(idx) - xc) / h;
        y0(idx) = pd(c, u, h, 0);
        d1(idx) = pd(c, u, h, 1);
        d2(idx) = pd(c, u, h, 2);
    end
end

function r = prow(n, u0, h, k)
    % Row giving the k-th x-derivative of a degree-n polynomial (coeffs c_0..c_n) at u0
    r = zeros(1, n+1);
    for j = k:n
        r(j+1) = factorial(j)/factorial(j-k) * u0^(j-k) / h^k;
    end
end

function v = pd(c, u, h, k)
    % k-th x-derivative of sum_j c_j u^j, with u = (x-xc)/h
    n = numel(c) - 1;
    v = zeros(size(u));
    for j = k:n
        v = v + c(j+1) * factorial(j)/factorial(j-k) * u.^(j-k);
    end
    v = v / h^k;
end