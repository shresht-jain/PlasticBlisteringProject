%% ===================== USER PARAMETERS =====================
imgFile      = "PrettyPeakwithRegularisation.png";
threshold    = 0.5;    % binarisation threshold (0-1)

midWindowPx  = 10;     % total width of the middle window, in pixels (centred on peak)

orderLeft    = 4;      % polynomial order, left segment
orderMid     = 4;      % polynomial order, middle segment
orderRight   = 4;      % polynomial order, right segment

contOrder    = 1;      % continuity at the joins:
                       %   0 = values match only (derivative will jump)
                       %   1 = values AND slopes match (no derivative spikes)
                       %   2 = values, slopes AND curvature match (smoothest)
                       % Orders must be >= contOrder (ideally > contOrder).

smoothPeak   = 1;      % moving-mean window used only for locating the peak (1 = no smoothing)
flipSlope    = true;   % true -> slope in visual convention (up = positive)
%% ===========================================================

im = imread(imgFile);
if size(im,3) == 3, im = rgb2gray(im); end
BW = imbinarize(im, threshold);

[hasWhite, topRow] = max(BW, [], 1);
topRow = double(topRow);
topRow(~hasWhite) = NaN;

x     = (1:size(BW,2))';
y     = topRow(:);
valid = isfinite(y);

% Locate peak
if smoothPeak > 1, yForPeak = smoothdata(y,'movmean',smoothPeak); else, yForPeak = y; end
[~, peakX] = min(yForPeak);       % use max(...) if your peak points downward

% Split into three regions
halfLeft  = floor(midWindowPx/2);
halfRight = midWindowPx - halfLeft;
midStart  = peakX - halfLeft;
midEnd    = peakX + halfRight;    % exclusive
xa = midStart;  xb = midEnd - 1;

leftIdx  = x <  xa;
midIdx   = x >= xa & x <= xb;
rightIdx = x >  xb;

% ---------- Joint constrained fit ----------
% Common scaled variable t = (x - peakX)/S keeps all segments in one coordinate system
S  = max(abs(x - peakX));
t  = (x - peakX) / S;
nL = orderLeft; nM = orderMid; nR = orderRight;

% Block-diagonal design matrix (data points only)
iL = leftIdx & valid;  iM = midIdx & valid;  iR = rightIdx & valid;
A = blkdiag(t(iL).^(0:nL), t(iM).^(0:nM), t(iR).^(0:nR));
b = [y(iL); y(iM); y(iR)];

% Continuity constraints: derivatives 0..contOrder agree across each join
ta = (xa - peakX)/S;  tb = (xb - peakX)/S;
C = zeros(0, nL+nM+nR+3);
for k = 0:contOrder
    ra = [ prow(nL,ta,S,k), -prow(nM,ta,S,k), zeros(1,nR+1) ];   % left = mid at xa
    rb = [ zeros(1,nL+1),    prow(nM,tb,S,k), -prow(nR,tb,S,k) ];% mid = right at xb
    C  = [C; ra; rb]; %#ok<AGROW>
end

% Solve the equality-constrained least squares via the KKT system
nc  = size(C,1);
KKT = [2*(A'*A), C'; C, zeros(nc)];
rhs = [2*(A'*b); zeros(nc,1)];
sol = KKT \ rhs;
w   = sol(1:size(A,2));

cL = w(1:nL+1);
cM = w(nL+2 : nL+nM+2);
cR = w(nL+nM+3 : end);

% ---------- Evaluate profile, slope and curvature ----------
yFit = nan(size(x));  dFit = nan(size(x));  ddFit = nan(size(x));
segs = {leftIdx, cL; midIdx, cM; rightIdx, cR};
for s = 1:3
    idx = segs{s,1};  c = segs{s,2};
    yFit(idx)  = pd(c, t(idx), S, 0);
    dFit(idx)  = pd(c, t(idx), S, 1);
    ddFit(idx) = pd(c, t(idx), S, 2);
end
if flipSlope, dFit = -dFit; ddFit = -ddFit; end

% ---------- Plots ----------
figure; imshow(im); hold on;
plot(x, y, 'r', 'LineWidth', 1);
plot(x, yFit, 'b-', 'LineWidth', 2);
xline(xa, 'g--'); xline(xb, 'g--');
hold off;
title(sprintf('Peak x = %d | orders L/M/R = %d/%d/%d | mid = %d px | continuity C^%d', ...
    peakX, nL, nM, nR, midWindowPx, contOrder));

figure;
subplot(2,1,1);
plot(x, dFit, 'b-', 'LineWidth', 1.5); hold on;
xline(xa,'g--'); xline(xb,'g--'); yline(0,'k:'); grid on;
ylabel('dy/dx'); title('First derivative');
subplot(2,1,2);
plot(x, ddFit, 'm-', 'LineWidth', 1.5); hold on;
xline(xa,'g--'); xline(xb,'g--'); yline(0,'k:'); grid on;
xlabel('x (pixel column)'); ylabel('d^2y/dx^2'); title('Second derivative');

% ---------- Diagnostics ----------
res = y - yFit;
fprintf('Mean residual  L: %.2f  M: %.2f  R: %.2f px\n', ...
    mean(res(leftIdx),'omitnan'), mean(res(midIdx),'omitnan'), mean(res(rightIdx),'omitnan'));
fprintf('RMS residual   L: %.2f  M: %.2f  R: %.2f px\n', ...
    rms(res(leftIdx & valid)), rms(res(midIdx & valid)), rms(res(rightIdx & valid)));
for k = 0:2
    ja = pd(cM,ta,S,k) - pd(cL,ta,S,k);
    jb = pd(cR,tb,S,k) - pd(cM,tb,S,k);
    fprintf('Jump in d^%d at xa: %9.2e   at xb: %9.2e\n', k, ja, jb);
end

% ---------------- local functions (must be at end of script) ----------------
function r = prow(n, t0, S, k)
    % Row giving the k-th x-derivative of a degree-n polynomial (coeffs c_0..c_n) at t0
    r = zeros(1, n+1);
    for j = k:n
        r(j+1) = factorial(j)/factorial(j-k) * t0^(j-k) / S^k;
    end
end

function v = pd(c, t, S, k)
    % k-th x-derivative of sum_j c_j t^j, with t = (x-x0)/S
    n = numel(c) - 1;
    v = zeros(size(t));
    for j = k:n
        v = v + c(j+1) * factorial(j)/factorial(j-k) * t.^(j-k);
    end
    v = v / S^k;
end